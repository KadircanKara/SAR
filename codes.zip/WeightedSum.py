from PathSolution import PathSolution

def mission_time_and_percentage_connectivity_ws(sol:PathSolution):
    return sol.mission_time*0.5 - sol.percentage_connectivity*0.5

def mission_time_and_percentage_connectivity_and_max_mean_tbv_ws(sol:PathSolution):
    return sol.mission_time/3 - sol.percentage_connectivity/3 + sol.max_mean_tbv/3